import telebot
import random
import os
import sys
from ns import image_recognition
from second_AI import Second_AI
import shutil
from telebot import types

token = '5117078081:AAHus-Jyn9u4bOJfIP_xxR6hjroOiWXOMKY'
bot = telebot.TeleBot(token)
flag, x, y = 0, 0, 0


@bot.message_handler(commands=['start'])
def Hello(message):
    sti = open('images/Hello.tgs', 'rb')
    bot.send_sticker(message.chat.id, sti)
    bot.send_message(message.chat.id, "Добро пожаловать, {0.first_name}!\nЯ - <b>{1.first_name}</b>, напиши /menu, что бы начать со мной общение.".format(message.from_user, bot.get_me()), parse_mode='html')
    
    
@bot.message_handler(commands=['menu'])
def Menu(message): 
    markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
    item1 = types.KeyboardButton("😊 Как дела?")
    item2 = types.KeyboardButton("🧠 Сгенерировать что-то интересное")
    item3 = types.KeyboardButton("💡 Определить, что изображено на фото")
    markup.add(item1, item2, item3)
    bot.send_message(message.chat.id, "Супер, вот, что я могу.".format(message.from_user, bot.get_me()), parse_mode='html', reply_markup=markup) 


@bot.message_handler(content_types=['text'])
def speach(message):
    global flag
    if message.chat.type == 'private':
        if message.text == '🧠 Сгенерировать что-то интересное':
            flag = 1
            bot.send_message(message.chat.id, "Отправьте мне 2 картинки и увидите магию ✨, но магия будет происходить с только с картинками формата .jpg и если вы их отправите файлами)")
            sti = open('images/Task.tgs', 'rb')
            bot.send_sticker(message.chat.id, sti)
        elif message.text == '😊 Как дела?':
            markup = types.InlineKeyboardMarkup(row_width=2)
            item1 = types.InlineKeyboardButton("Хорошо", callback_data='good')
            item2 = types.InlineKeyboardButton("Не очень", callback_data='bad')
            markup.add(item1, item2)
            bot.send_message(message.chat.id, 'Отлично, сам как?', reply_markup=markup)
        elif message.text == "💡 Определить, что изображено на фото":
            flag = 2
            bot.send_message(message.chat.id, "Отправьте мне картинку и я подскажу, что на ней изображено. Но я смогу я вам помочь только если: 1. Разрешение фотографии будет 224x224 2. Формат фотографии будет .jpg")
            sti = open('images/Task_2.tgs', 'rb')
            bot.send_sticker(message.chat.id, sti)            
        else:
            bot.send_message(message.chat.id, 'Я не знаю что ответить 😢')
            
@bot.message_handler(content_types=['document'])
def handle_docs_photo(message):
    global flag, x, y
    if flag == 1:
        x += 1
        try:
            path = 'neuro/1/RC'
            if x == 1:
                os.mkdir(path, 0o774)
                chat_id = message.chat.id
                file_info = bot.get_file(message.document.file_id)
                downloaded_file = bot.download_file(file_info.file_path)            
                src = 'C:/Users/StefFashka/Downloads/Bot/neuro/1/RC/' + message.document.file_name;
                with open(src, 'wb') as new_file:
                    new_file.write(downloaded_file)
                bot.reply_to(message, "Записываю ⚙️")
                bot.send_message(message.chat.id, 'Нужна ещё 1 картинка') 
                
            elif x == 2:
                chat_id = message.chat.id
                file_info = bot.get_file(message.document.file_id)
                downloaded_file = bot.download_file(file_info.file_path)            
                src = 'C:/Users/StefFashka/Downloads/Bot/neuro/1/RC/' + message.document.file_name;
                with open(src, 'wb') as new_file:
                    new_file.write(downloaded_file)
                bot.reply_to(message, "Отлично️")
                sti = open('images/Loading.tgs', 'rb')
                bot.send_sticker(message.chat.id, sti)
                img = 'neuro/1/RC/cat.jpg'
                img = 'neuro/1/RC/image_style_3.jpg'
                Second_AI(img, img_style)
                result = open('result_3.jpg', 'rb')
                bot.send_photo(message.chat.id, result)
                shutil.rmtree(path, ignore_errors=True)
                x = 0
        except Exception as e:
            bot.reply_to(message, e) 
            
    elif flag == 2:
        try:
            path = 'neuro/2/RC'
            os.mkdir(path, 0o774)
            chat_id = message.chat.id
            file_info = bot.get_file(message.document.file_id)
            downloaded_file = bot.download_file(file_info.file_path)
            src = 'C:/Users/StefFashka/Downloads/Bot/neuro/2/RC/' + message.document.file_name;
            with open(src, 'wb') as new_file:
                new_file.write(downloaded_file)
            bot.reply_to(message, "Отлично️")
            sti = open('images/Loading.tgs', 'rb')
            bot.send_sticker(message.chat.id, sti)
            img = 'neuro/2/RC/tiger.jpg'
            result = image_recognition(img)
            bot.send_message(message.chat.id, result) 
            shutil.rmtree(path, ignore_errors=True)
        except Exception as e:
            bot.reply_to(message, e)        
        
            
@bot.callback_query_handler(func=lambda call: True)
def callback_inline(call):
    try:
        if call.message:
            if call.data == 'good':
                bot.send_message(call.message.chat.id, 'Супер 😊')
            elif call.data == 'bad':
                bot.send_message(call.message.chat.id, 'Бывает 😢')
 
            bot.edit_message_text(chat_id=call.message.chat.id, message_id=call.message.message_id, text="😊 Как дела?",
                reply_markup=None)
 
            
    except Exception as e:
        print(repr(e))

#Run   
bot.polling(none_stop=True)